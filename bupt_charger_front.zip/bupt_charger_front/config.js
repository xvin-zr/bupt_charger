// const serverURL = 'http://localhost:3003';
const serverURL = 'http://10.128.251.153:3003'; // my server
// const serverURL = "http://10.28.163.203:7777";
// const serverURL = "http://10.28.131.78:8080";
// const serverURL = "http://10.28.145.45:8001";
// const serverURL = "http://10.128.225.231:80"

const preToken = "Bearer ";